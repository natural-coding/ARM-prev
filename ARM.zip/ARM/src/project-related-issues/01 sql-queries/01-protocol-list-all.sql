SELECT * FROM pdo.protocol_table order by proto_ordnum desc



SELECT proto_ordnum FROM pdo.protocol_table order by proto_ordnum desc